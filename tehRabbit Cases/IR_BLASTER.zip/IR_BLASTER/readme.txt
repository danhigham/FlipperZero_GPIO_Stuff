IR BLASTER Protective Case

Bill of Materials

28mm lense: I took one out of this flashlight:
    https://www.amazon.com/UltraFire-Illuminator-Flashlight-Zoomable-Predator/dp/B09KZ7G4NH/ref=sr_1_16?keywords=ir+flashlight&sr=8-16

    I think these are the same thing:
    https://www.aliexpress.us/item/2251832035134780.html?spm=a2g0o.productlist.main.3.1ceb48c0gT0oF9&algo_pvid=9ba2312a-85fe-4e99-8779-5443c05ff88d&algo_exp_id=9ba2312a-85fe-4e99-8779-5443c05ff88d-1&pdp_npi=3%40dis%21USD%212.76%212.59%21%21%21%21%21%4021021f7b16817626462758439d06d1%2114622277918%21sea%21US%210&curPageLogUid=1vqq4yXfJ4rA

M3x4x5mm brass threaded insert, mine came from this kit:
    https://www.amazon.com/Hilitchi-Threaded-Embedment-Assortment-Projects/dp/B07VFZWWXY/ref=sr_1_4?keywords=brass%2Bthreaded%2Binserts%2B3d%2Bprinting&sr=8-4&th=1

M3x8mm screw, again from a kit:
    https://www.amazon.com/1625PCS-Assortment-Machine-Washers-Head/dp/B0BKZWWTJY/ref=sr_1_14?keywords=metric+socket+head+screw+assortment&sr=8-14


Printing instructions:
    Print the body with the hole for the lense on the build plate with no supports.
    Print the lid with the flat side down and the graphic facing up.


Assembly:
    Press the brass insert in with a soldering iron.
    The lense is a very tight fit, you might need to use the handle side of a screw driver to pop it in place.
